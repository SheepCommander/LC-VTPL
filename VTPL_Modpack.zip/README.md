# LC modpack for VTPL!

The Lethal Company modpack for the VTubers PLace discord! https://discord.gg/vtubersplace


Too lazy to write out an actual mod list. [Please wait... Girls are now loading...]


## Changelog

### Sheep-v1.a An_Edit-v1
Angeless's version of my modpack.

### VTPL_Modpack 2.0.2
Small updates to Sheep-v1.a:
- Deleted useless "LethalSettings" mod
- Modified some more config stuff c:
- Has latest dependencies