# LC modpack for VTPL!

The Lethal Company modpack for the VTubers PLace discord! https://discord.gg/vtubersplace


Too lazy to write out an actual mod list. [Please wait... Girls are now loading...]


## Changelog

### Sheep-v1.a An_Edit-v1
Angeless's version of my modpack.

### VTPL_Modpack 2.0.2
Small updates to Sheep-v1.a:
- Deleted useless "LethalSettings" mod
- Modified some more config stuff c:
- Has latest dependencies

### VTPL_Modpack 2.0.3
No changes. Just trying to get thunderstore to work.

### VTPL_Modpack 2.0.4
Single change to configs. Still completely compatible with the 2.0.2 version.

### VTPL_Modpack 3.0.0
- Removed LethalExpansion (replace with LethalCore. Do not worry about fumoscrap telling you to install it, you can safely ignore that)
- Removed uhhh some other things idr
- Added holo music, holo tv, and two other things
- Updated configs
- I hope everything works

#### VTPL_Modpack 3.0.1
- removed a couple things that aren't funny.

#### 3.0.2
- hopefully fix audio

#### 3.0.3 + maintenence
- added giant chibi, yaz's holomodels port, biboghostgirl
- removed the backrooms | rng was wacky 
- added LethalExpansion config file in case someone accidententally downloads it (absolutely not me) set up to negate all its changes 
- changed some minor config stuff im too lazy to list
- i (Angeless) have manually checked the whole dependency list to make sure everythingis fine, yes i hate myself

#### 3.0.4 (maintenence)
- checked any mods update
- sorted the manifest file cuz yes (sorted by autor name)